from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3

app = Flask(__name__)
CORS(app)

@app.route('/predict', methods=['POST'])
def predict():
    # Replace with YOLO inference
    result = {"object":"person","confidence":0.95}

    conn = sqlite3.connect('detections.db')
    cur = conn.cursor()
    cur.execute('INSERT INTO detections(object_name,confidence) VALUES(?,?)',
                (result["object"], result["confidence"]))
    conn.commit()
    conn.close()

    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)
