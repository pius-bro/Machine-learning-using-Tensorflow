# Object Detection Full Stack Project

Architecture:
- Frontend: HTML/CSS/JS
- Backend: Flask + YOLO
- Database: SQLite
- Model: Place your trained best.pt inside backend/

Run:
1. pip install -r backend/requirements.txt
2. python backend/app.py
3. Open frontend/index.html or serve it with a web server.

Deployment:
- Push to GitHub
- Deploy backend on Render/Railway
- Host frontend on GitHub Pages
