from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
import os
from datetime import datetime

from config import IMAGES_PER_EMPLOYEE
from database import db_manager as db
from recognition import face_trainer, face_recognizer
from recognition.utils import decode_base64_image

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-key-change-in-production")

# Initialize database on startup
db.init_db()


# ---------------------------------------------------------------------------
# Pages
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template(
        "index.html",
        employee_count=db.employee_count(),
        model_ready=face_recognizer.is_model_ready()
    )


@app.route("/register")
def register_page():
    return render_template("register.html", images_per_employee=IMAGES_PER_EMPLOYEE)


@app.route("/attendance")
def attendance_page():
    if not face_recognizer.is_model_ready():
        flash("No employees have been registered yet. Please register at least one employee first.", "warning")
        return redirect(url_for("register_page"))
    return render_template("attendance.html")


@app.route("/dashboard")
def dashboard_page():
    today_records = db.get_today_attendance()
    return render_template(
        "dashboard.html",
        records=today_records,
        total_employees=db.employee_count(),
        checked_in_count=sum(1 for r in today_records if r["check_in"]),
        today=datetime.now().strftime("%Y-%m-%d")
    )


@app.route("/employees")
def employees_page():
    return render_template("employees.html", employees=db.get_all_employees())


# ---------------------------------------------------------------------------
# API: Registration / Training
# ---------------------------------------------------------------------------

@app.route("/api/register", methods=["POST"])
def api_register():
    """
    Step 1 of registration: create the employee record and reserve a label_id.
    Expects JSON: {employee_id, name, department, email}
    """
    data = request.get_json(force=True)
    employee_id = (data.get("employee_id") or "").strip()
    name = (data.get("name") or "").strip()
    department = (data.get("department") or "").strip()
    email = (data.get("email") or "").strip()

    if not employee_id or not name:
        return jsonify({"success": False, "message": "Employee ID and Name are required."}), 400

    if db.get_employee_by_employee_id(employee_id):
        return jsonify({"success": False, "message": "An employee with this ID already exists."}), 400

    label_id = db.get_next_label_id()
    success, message = db.add_employee(employee_id, name, department, email, label_id)

    if not success:
        return jsonify({"success": False, "message": message}), 400

    return jsonify({"success": True, "message": message, "label_id": label_id})


@app.route("/api/capture_sample", methods=["POST"])
def api_capture_sample():
    """
    Receives a single webcam frame during registration, detects/crops the face,
    and stores it under the employee's dataset folder.
    Expects JSON: {label_id, image (base64 data URL), sample_index}
    """
    data = request.get_json(force=True)
    label_id = data.get("label_id")
    image_data = data.get("image")
    sample_index = data.get("sample_index", 0)

    if label_id is None or not image_data:
        return jsonify({"success": False, "message": "Missing label_id or image."}), 400

    img = decode_base64_image(image_data)
    if img is None:
        return jsonify({"success": False, "message": "Could not decode image."}), 400

    success, message = face_trainer.save_face_sample(label_id, img, sample_index)
    return jsonify({"success": success, "message": message})


@app.route("/api/train", methods=["POST"])
def api_train():
    """Trigger a full retrain of the LBPH model. Called after all samples are captured."""
    success, message = face_trainer.train_model()
    return jsonify({"success": success, "message": message})


# ---------------------------------------------------------------------------
# API: Live Attendance Recognition
# ---------------------------------------------------------------------------

@app.route("/api/recognize", methods=["POST"])
def api_recognize():
    """
    Receives a live camera frame, attempts to recognize the face, and marks
    attendance if a confident match is found.
    Expects JSON: {image (base64 data URL)}
    """
    data = request.get_json(force=True)
    image_data = data.get("image")

    if not image_data:
        return jsonify({"success": False, "status": "error", "message": "No image received."}), 400

    img = decode_base64_image(image_data)
    if img is None:
        return jsonify({"success": False, "status": "error", "message": "Could not decode image."}), 400

    result = face_recognizer.recognize(img)

    if result["status"] == "no_model":
        return jsonify({"success": False, "status": "no_model", "message": "No trained model available yet."})

    if result["status"] == "no_face":
        return jsonify({"success": False, "status": "no_face", "message": "No face detected in frame."})

    if result["status"] == "unknown":
        return jsonify({
            "success": False,
            "status": "unknown",
            "message": "Face not recognized. Not an authorized employee.",
            "confidence": result["confidence"]
        })

    # recognized
    employee = db.get_employee_by_label(result["label_id"])
    if employee is None:
        return jsonify({"success": False, "status": "error", "message": "Recognized label has no matching employee record."})

    attendance_result = db.mark_attendance(employee["employee_id"], employee["name"])

    return jsonify({
        "success": True,
        "status": "recognized",
        "employee_id": employee["employee_id"],
        "name": employee["name"],
        "department": employee["department"],
        "confidence": round(result["confidence"], 2),
        "action": attendance_result["action"],
        "message": attendance_result["message"],
        "time": attendance_result["time"]
    })


# ---------------------------------------------------------------------------
# API: Employee management
# ---------------------------------------------------------------------------

@app.route("/api/employees/<employee_id>/delete", methods=["POST"])
def api_delete_employee(employee_id):
    employee = db.get_employee_by_employee_id(employee_id)
    if employee is None:
        flash("Employee not found.", "danger")
        return redirect(url_for("employees_page"))

    face_trainer.delete_employee_dataset(employee["label_id"])
    db.delete_employee(employee_id)
    face_trainer.train_model()  # retrain on remaining data (safe even if it becomes empty)

    flash(f"Employee {employee['name']} removed successfully.", "success")
    return redirect(url_for("employees_page"))


# ---------------------------------------------------------------------------
# API: Attendance records
# ---------------------------------------------------------------------------

@app.route("/api/attendance/today")
def api_attendance_today():
    return jsonify(db.get_today_attendance())


@app.route("/api/attendance/by_date")
def api_attendance_by_date():
    date_str = request.args.get("date", datetime.now().strftime("%Y-%m-%d"))
    return jsonify(db.get_attendance_by_date(date_str))


if __name__ == "__main__":
    # use_reloader=False avoids double-loading the OpenCV model / camera state on Windows debug reloads
    app.run(host="0.0.0.0", port=5000, debug=True, use_reloader=False)
