import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Storage paths
DATASET_DIR = os.path.join(BASE_DIR, "dataset")
MODELS_DIR = os.path.join(BASE_DIR, "models")
TRAINER_PATH = os.path.join(MODELS_DIR, "trainer.yml")
DB_PATH = os.path.join(BASE_DIR, "attendance.db")

# Face detection / recognition settings
FACE_SIZE = (200, 200)                # size faces are normalized to before training
IMAGES_PER_EMPLOYEE = 20              # number of samples captured during registration
CONFIDENCE_THRESHOLD = 75             # LBPH distance: LOWER = more confident match. Reject anything above this.
MIN_FACE_SIZE = (80, 80)              # ignore tiny/false-positive detections

# Attendance rules
MIN_MINUTES_BETWEEN_CHECKIN_CHECKOUT = 1   # minimum gap (minutes) before a check-out can be recorded after check-in

# Make sure folders exist
os.makedirs(DATASET_DIR, exist_ok=True)
os.makedirs(MODELS_DIR, exist_ok=True)
