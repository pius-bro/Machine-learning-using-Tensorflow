"""
Database layer for the Facial Recognition Attendance System.
Uses SQLite (zero-config, file-based, ships with Python) so the project
runs anywhere with no external DB server required.
"""
import sqlite3
import os
import sys
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import DB_PATH


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Create tables if they do not already exist."""
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            department TEXT,
            email TEXT,
            label_id INTEGER UNIQUE NOT NULL,
            created_at TEXT NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id TEXT NOT NULL,
            name TEXT NOT NULL,
            date TEXT NOT NULL,
            check_in TEXT,
            check_out TEXT,
            FOREIGN KEY (employee_id) REFERENCES employees (employee_id),
            UNIQUE (employee_id, date)
        )
    """)

    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Employee operations
# ---------------------------------------------------------------------------

def get_next_label_id():
    conn = get_connection()
    row = conn.execute("SELECT MAX(label_id) as max_label FROM employees").fetchone()
    conn.close()
    if row is None or row["max_label"] is None:
        return 0
    return row["max_label"] + 1


def add_employee(employee_id, name, department, email, label_id):
    conn = get_connection()
    try:
        conn.execute(
            """INSERT INTO employees (employee_id, name, department, email, label_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (employee_id, name, department, email, label_id, datetime.now().isoformat())
        )
        conn.commit()
        return True, "Employee registered successfully."
    except sqlite3.IntegrityError as e:
        return False, f"Employee ID already exists or duplicate label: {e}"
    finally:
        conn.close()


def get_employee_by_employee_id(employee_id):
    conn = get_connection()
    row = conn.execute("SELECT * FROM employees WHERE employee_id = ?", (employee_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_employee_by_label(label_id):
    conn = get_connection()
    row = conn.execute("SELECT * FROM employees WHERE label_id = ?", (label_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_all_employees():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM employees ORDER BY created_at DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def delete_employee(employee_id):
    conn = get_connection()
    # Child records (attendance) must be removed before the parent employee row,
    # otherwise the foreign key constraint rejects the delete.
    conn.execute("DELETE FROM attendance WHERE employee_id = ?", (employee_id,))
    conn.execute("DELETE FROM employees WHERE employee_id = ?", (employee_id,))
    conn.commit()
    conn.close()


def employee_count():
    conn = get_connection()
    row = conn.execute("SELECT COUNT(*) as c FROM employees").fetchone()
    conn.close()
    return row["c"]


# ---------------------------------------------------------------------------
# Attendance operations
# ---------------------------------------------------------------------------

def get_today_record(employee_id):
    today = datetime.now().strftime("%Y-%m-%d")
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM attendance WHERE employee_id = ? AND date = ?",
        (employee_id, today)
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def mark_attendance(employee_id, name, min_gap_minutes=1):
    """
    Handles check-in / check-out logic for a recognized employee.
    Returns a dict: {action, message, time}
    """
    today = datetime.now().strftime("%Y-%m-%d")
    now = datetime.now()
    now_str = now.strftime("%H:%M:%S")

    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM attendance WHERE employee_id = ? AND date = ?",
        (employee_id, today)
    ).fetchone()

    if row is None:
        # First sighting today -> check-in
        conn.execute(
            "INSERT INTO attendance (employee_id, name, date, check_in, check_out) VALUES (?, ?, ?, ?, NULL)",
            (employee_id, name, today, now_str)
        )
        conn.commit()
        conn.close()
        return {"action": "check_in", "message": f"Check-in recorded at {now_str}", "time": now_str}

    record = dict(row)
    if record["check_out"] is None:
        # Already checked in - see if enough time has passed to allow check-out
        check_in_time = datetime.strptime(record["check_in"], "%H:%M:%S")
        check_in_dt = now.replace(hour=check_in_time.hour, minute=check_in_time.minute, second=check_in_time.second)
        elapsed_minutes = (now - check_in_dt).total_seconds() / 60.0

        if elapsed_minutes < min_gap_minutes:
            conn.close()
            return {"action": "already_checked_in", "message": f"Already checked in at {record['check_in']}", "time": record["check_in"]}

        conn.execute(
            "UPDATE attendance SET check_out = ? WHERE employee_id = ? AND date = ?",
            (now_str, employee_id, today)
        )
        conn.commit()
        conn.close()
        return {"action": "check_out", "message": f"Check-out recorded at {now_str}", "time": now_str}

    conn.close()
    return {"action": "complete", "message": "Attendance already completed for today", "time": record["check_out"]}


def get_attendance_by_date(date_str):
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM attendance WHERE date = ? ORDER BY check_in DESC",
        (date_str,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_today_attendance():
    today = datetime.now().strftime("%Y-%m-%d")
    return get_attendance_by_date(today)


def get_all_attendance(limit=200):
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM attendance ORDER BY date DESC, check_in DESC LIMIT ?",
        (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]
