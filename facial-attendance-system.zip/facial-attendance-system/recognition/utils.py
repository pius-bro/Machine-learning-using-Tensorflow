"""Shared helpers for decoding camera frames and detecting faces."""
import base64
import re
import numpy as np
import cv2
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import MIN_FACE_SIZE

_CASCADE_PATH = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
_face_cascade = cv2.CascadeClassifier(_CASCADE_PATH)


def decode_base64_image(data_url):
    """
    Convert a 'data:image/jpeg;base64,....' string (as sent from the browser
    canvas) into an OpenCV BGR image (numpy array). Returns None on failure.
    """
    try:
        img_str = re.sub("^data:image/.+;base64,", "", data_url)
        img_bytes = base64.b64decode(img_str)
        np_arr = np.frombuffer(img_bytes, np.uint8)
        img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        return img
    except Exception:
        return None


def detect_faces(gray_image):
    """Return list of (x, y, w, h) boxes for all faces found in a grayscale image."""
    faces = _face_cascade.detectMultiScale(
        gray_image,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=MIN_FACE_SIZE
    )
    return faces


def largest_face(faces):
    """Given a list of face boxes, return the largest one (by area)."""
    if len(faces) == 0:
        return None
    return max(faces, key=lambda f: f[2] * f[3])


def to_gray(img):
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
