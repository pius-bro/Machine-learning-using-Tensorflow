"""
Loads the trained LBPH model and performs recognition on incoming camera frames.
The model is cached in memory and reloaded whenever the file's modification
time changes (i.e. right after a retrain), so the Flask app never needs a restart.
"""
import os
import sys
import cv2

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import TRAINER_PATH, FACE_SIZE, CONFIDENCE_THRESHOLD
from recognition.utils import detect_faces, largest_face, to_gray

_recognizer = None
_trainer_mtime = None


def _load_recognizer():
    global _recognizer, _trainer_mtime
    if not os.path.exists(TRAINER_PATH):
        _recognizer = None
        _trainer_mtime = None
        return None

    mtime = os.path.getmtime(TRAINER_PATH)
    if _recognizer is None or mtime != _trainer_mtime:
        _recognizer = cv2.face.LBPHFaceRecognizer_create()
        _recognizer.read(TRAINER_PATH)
        _trainer_mtime = mtime
    return _recognizer


def is_model_ready():
    return os.path.exists(TRAINER_PATH)


def recognize(bgr_image):
    """
    Detect the largest face in the frame and attempt to identify it.
    Returns a dict:
        {status: "no_model" | "no_face" | "multiple_faces" | "unknown" | "recognized",
         label_id: int or None,
         confidence: float or None,
         box: (x, y, w, h) or None}
    """
    recognizer = _load_recognizer()
    if recognizer is None:
        return {"status": "no_model", "label_id": None, "confidence": None, "box": None}

    gray = to_gray(bgr_image)
    faces = detect_faces(gray)

    if len(faces) == 0:
        return {"status": "no_face", "label_id": None, "confidence": None, "box": None}

    box = largest_face(faces)
    (x, y, w, h) = box
    face_crop = gray[y:y + h, x:x + w]
    face_crop = cv2.resize(face_crop, FACE_SIZE)
    face_crop = cv2.equalizeHist(face_crop)

    label_id, confidence = recognizer.predict(face_crop)
    # LBPH: LOWER confidence value = better match
    if confidence <= CONFIDENCE_THRESHOLD:
        return {"status": "recognized", "label_id": label_id, "confidence": float(confidence), "box": box}
    else:
        return {"status": "unknown", "label_id": None, "confidence": float(confidence), "box": box}
