"""
Handles:
 1. Saving cropped, normalized face images captured during registration.
 2. (Re)training the LBPH face recognizer across the entire dataset.
"""
import os
import sys
import cv2
import numpy as np

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import DATASET_DIR, TRAINER_PATH, FACE_SIZE
from recognition.utils import detect_faces, largest_face, to_gray


def employee_dataset_dir(label_id):
    path = os.path.join(DATASET_DIR, str(label_id))
    os.makedirs(path, exist_ok=True)
    return path


def save_face_sample(label_id, bgr_image, sample_index):
    """
    Detect the single largest face in bgr_image, crop + normalize it,
    and save it to disk under the employee's dataset folder.
    Returns (success: bool, message: str)
    """
    gray = to_gray(bgr_image)
    faces = detect_faces(gray)

    if len(faces) == 0:
        return False, "No face detected. Please face the camera directly."
    if len(faces) > 1:
        return False, "Multiple faces detected. Only one person should be in frame."

    (x, y, w, h) = largest_face(faces)
    face_crop = gray[y:y + h, x:x + w]
    face_crop = cv2.resize(face_crop, FACE_SIZE)
    face_crop = cv2.equalizeHist(face_crop)  # normalize lighting

    folder = employee_dataset_dir(label_id)
    filepath = os.path.join(folder, f"{sample_index}.jpg")
    cv2.imwrite(filepath, face_crop)
    return True, "Sample captured."


def train_model():
    """
    Rebuild the LBPH model using every saved face image across all employees.
    Must be called after any new employee registration (or deletion) for the
    recognizer to be aware of the change.
    """
    faces = []
    labels = []

    if not os.path.isdir(DATASET_DIR):
        return False, "No dataset directory found."

    label_folders = [d for d in os.listdir(DATASET_DIR) if os.path.isdir(os.path.join(DATASET_DIR, d))]

    if len(label_folders) == 0:
        return False, "No training data available yet."

    for label_folder in label_folders:
        try:
            label_id = int(label_folder)
        except ValueError:
            continue

        folder_path = os.path.join(DATASET_DIR, label_folder)
        for filename in os.listdir(folder_path):
            if not filename.lower().endswith((".jpg", ".jpeg", ".png")):
                continue
            filepath = os.path.join(folder_path, filename)
            img = cv2.imread(filepath, cv2.IMREAD_GRAYSCALE)
            if img is None:
                continue
            faces.append(img)
            labels.append(label_id)

    if len(faces) == 0:
        return False, "No valid face images found to train on."

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.train(faces, np.array(labels))
    recognizer.write(TRAINER_PATH)

    return True, f"Model trained on {len(faces)} images across {len(label_folders)} employee(s)."


def delete_employee_dataset(label_id):
    """Remove all stored face samples for an employee (used when deleting a profile)."""
    folder = os.path.join(DATASET_DIR, str(label_id))
    if os.path.isdir(folder):
        for f in os.listdir(folder):
            os.remove(os.path.join(folder, f))
        os.rmdir(folder)
