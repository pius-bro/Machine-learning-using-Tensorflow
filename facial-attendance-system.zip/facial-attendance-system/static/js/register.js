// -----------------------------------------------------------------------
// Registration flow:
// 1. Submit employee details -> get back a label_id from the server.
// 2. Start webcam, capture N samples (one every ~600ms) -> POST each to
//    /api/capture_sample for face detection + cropping + storage.
// 3. Once all samples are captured, POST /api/train to rebuild the model.
// -----------------------------------------------------------------------

let currentLabelId = null;
let stream = null;
let sampleIndex = 0;
let capturing = false;

const startFormBtn = document.getElementById("start-capture-btn");
const formError = document.getElementById("form-error");
const stepForm = document.getElementById("step-form");
const stepCapture = document.getElementById("step-capture");
const video = document.getElementById("video");
const captureCanvas = document.getElementById("capture-canvas");
const beginCaptureBtn = document.getElementById("begin-capture-btn");
const finishBtn = document.getElementById("finish-btn");
const progressFill = document.getElementById("progress-fill");
const captureStatus = document.getElementById("capture-status");

startFormBtn.addEventListener("click", async () => {
    formError.textContent = "";
    const employee_id = document.getElementById("employee_id").value.trim();
    const name = document.getElementById("name").value.trim();
    const department = document.getElementById("department").value.trim();
    const email = document.getElementById("email").value.trim();

    if (!employee_id || !name) {
        formError.textContent = "Employee ID and Name are required.";
        return;
    }

    startFormBtn.disabled = true;
    startFormBtn.textContent = "Please wait...";

    try {
        const res = await fetch("/api/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ employee_id, name, department, email })
        });
        const data = await res.json();

        if (!data.success) {
            formError.textContent = data.message;
            startFormBtn.disabled = false;
            startFormBtn.textContent = "Continue to Face Capture";
            return;
        }

        currentLabelId = data.label_id;
        stepForm.style.display = "none";
        stepCapture.style.display = "block";
        await initCamera();
    } catch (err) {
        formError.textContent = "Could not reach the server. Please try again.";
        startFormBtn.disabled = false;
        startFormBtn.textContent = "Continue to Face Capture";
    }
});

async function initCamera() {
    try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { width: 480, height: 360 }, audio: false });
        video.srcObject = stream;
    } catch (err) {
        captureStatus.className = "scanner-status status-error";
        captureStatus.textContent = "Camera access denied or unavailable. Please allow camera permissions and reload.";
    }
}

beginCaptureBtn.addEventListener("click", () => {
    if (capturing || !currentLabelId) return;
    capturing = true;
    sampleIndex = 0;
    beginCaptureBtn.disabled = true;
    beginCaptureBtn.textContent = "Capturing...";
    captureStatus.className = "scanner-status status-scanning";
    captureLoop();
});

function captureFrame() {
    const ctx = captureCanvas.getContext("2d");
    captureCanvas.width = video.videoWidth || 480;
    captureCanvas.height = video.videoHeight || 360;
    ctx.drawImage(video, 0, 0, captureCanvas.width, captureCanvas.height);
    return captureCanvas.toDataURL("image/jpeg", 0.85);
}

async function captureLoop() {
    if (sampleIndex >= IMAGES_PER_EMPLOYEE) {
        finishCapturing();
        return;
    }

    const imageData = captureFrame();

    try {
        const res = await fetch("/api/capture_sample", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ label_id: currentLabelId, image: imageData, sample_index: sampleIndex })
        });
        const data = await res.json();

        if (data.success) {
            sampleIndex += 1;
            const pct = Math.round((sampleIndex / IMAGES_PER_EMPLOYEE) * 100);
            progressFill.style.width = pct + "%";
            captureStatus.textContent = `Captured ${sampleIndex} / ${IMAGES_PER_EMPLOYEE} samples...`;
        } else {
            // Detection issue (no face / multiple faces) - just retry, don't count it
            captureStatus.textContent = data.message;
        }
    } catch (err) {
        captureStatus.className = "scanner-status status-error";
        captureStatus.textContent = "Connection error while capturing. Retrying...";
    }

    setTimeout(captureLoop, 550);
}

async function finishCapturing() {
    captureStatus.className = "scanner-status status-scanning";
    captureStatus.textContent = "All samples captured. Training recognition model...";
    beginCaptureBtn.style.display = "none";

    try {
        const res = await fetch("/api/train", { method: "POST" });
        const data = await res.json();

        if (data.success) {
            captureStatus.className = "scanner-status status-success";
            captureStatus.textContent = "✓ Registration complete. Model trained successfully.";
        } else {
            captureStatus.className = "scanner-status status-error";
            captureStatus.textContent = "Training failed: " + data.message;
        }
    } catch (err) {
        captureStatus.className = "scanner-status status-error";
        captureStatus.textContent = "Could not reach the server to train the model.";
    }

    finishBtn.style.display = "inline-block";
    if (stream) {
        stream.getTracks().forEach(t => t.stop());
    }
}
