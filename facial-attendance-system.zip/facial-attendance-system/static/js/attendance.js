// -----------------------------------------------------------------------
// Live attendance flow:
// Continuously capture a frame every ~1.8s and POST to /api/recognize.
// The server detects + identifies the face and marks check-in/check-out.
// We throttle re-marking the SAME employee back-to-back within this session
// so the log doesn't spam once they've already been recognized.
// -----------------------------------------------------------------------

const video = document.getElementById("video");
const captureCanvas = document.getElementById("capture-canvas");
const scanStatus = document.getElementById("scan-status");
const confidenceReadout = document.getElementById("confidence-readout");
const recentLog = document.getElementById("recent-log");

const SCAN_INTERVAL_MS = 1800;
let lastRecognizedId = null;
let lastRecognizedAt = 0;
const RE_ANNOUNCE_COOLDOWN_MS = 15000; // avoid re-logging the same person every 1.8s while they stand there

let recentEntries = [];

async function initCamera() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 480, height: 360 }, audio: false });
        video.srcObject = stream;
        scanStatus.className = "scanner-status status-scanning";
        scanStatus.textContent = "Scanning for a face...";
        setInterval(scanFrame, SCAN_INTERVAL_MS);
    } catch (err) {
        scanStatus.className = "scanner-status status-error";
        scanStatus.textContent = "Camera access denied or unavailable. Please allow camera permissions and reload.";
    }
}

function captureFrame() {
    const ctx = captureCanvas.getContext("2d");
    captureCanvas.width = video.videoWidth || 480;
    captureCanvas.height = video.videoHeight || 360;
    ctx.drawImage(video, 0, 0, captureCanvas.width, captureCanvas.height);
    return captureCanvas.toDataURL("image/jpeg", 0.85);
}

async function scanFrame() {
    if (!video.videoWidth) return;
    const imageData = captureFrame();

    try {
        const res = await fetch("/api/recognize", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ image: imageData })
        });
        const data = await res.json();
        handleResult(data);
    } catch (err) {
        scanStatus.className = "scanner-status status-error";
        scanStatus.textContent = "Connection error. Retrying...";
    }
}

function handleResult(data) {
    confidenceReadout.textContent = "";

    switch (data.status) {
        case "no_model":
            scanStatus.className = "scanner-status status-error";
            scanStatus.textContent = "No employees registered yet.";
            break;

        case "no_face":
            scanStatus.className = "scanner-status status-scanning";
            scanStatus.textContent = "Scanning for a face...";
            break;

        case "unknown":
            scanStatus.className = "scanner-status status-warn";
            scanStatus.textContent = "Face not recognized — not an authorized employee.";
            if (data.confidence !== undefined) {
                confidenceReadout.textContent = `match distance: ${data.confidence.toFixed(1)} (threshold not met)`;
            }
            break;

        case "recognized": {
            const now = Date.now();
            const isNewAnnouncement = (data.employee_id !== lastRecognizedId) ||
                                       (now - lastRecognizedAt > RE_ANNOUNCE_COOLDOWN_MS);

            scanStatus.className = "status-success scanner-status";
            scanStatus.textContent = `✓ ${data.name} — ${data.message}`;
            confidenceReadout.textContent = `match distance: ${data.confidence} · confidence threshold OK`;

            if (isNewAnnouncement) {
                lastRecognizedId = data.employee_id;
                lastRecognizedAt = now;
                addToLog(data);
            }
            break;
        }

        default:
            scanStatus.className = "scanner-status status-error";
            scanStatus.textContent = data.message || "Unexpected response from server.";
    }
}

function addToLog(data) {
    const time = new Date().toLocaleTimeString();
    recentEntries.unshift({ name: data.name, employee_id: data.employee_id, action: data.action, message: data.message, time });
    recentEntries = recentEntries.slice(0, 8);

    recentLog.innerHTML = recentEntries.map(e => `
        <div style="display:flex; justify-content:space-between; padding:10px 0; border-bottom:1px solid var(--border); font-size:0.85rem;">
            <div>
                <strong>${escapeHtml(e.name)}</strong>
                <div style="color:var(--text-dim); font-family: var(--font-mono); font-size:0.75rem;">${escapeHtml(e.employee_id)}</div>
            </div>
            <div style="text-align:right;">
                <span class="badge ${e.action === 'check_in' ? 'badge-in' : (e.action === 'check_out' ? 'badge-out' : 'badge-pending')}">${e.action.replace('_',' ')}</span>
                <div style="color:var(--text-dim); font-size:0.75rem; margin-top:4px;">${e.time}</div>
            </div>
        </div>
    `).join("");
}

function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
}

initCamera();
