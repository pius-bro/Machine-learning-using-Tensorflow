# FaceTrack — Facial Recognition Employee Attendance System

A complete, working attendance system that uses your device camera to recognize
employees' faces and automatically log check-in / check-out times — no cards,
PINs, or manual entry required.

Built with **Flask + OpenCV (Haar Cascade + LBPH)** and **SQLite**. Deliberately
avoids `dlib` / `face_recognition` — those require compiling C++ code and are a
constant source of install failures on Windows and cloud platforms. Everything
here installs from pure pip wheels.

---

## How it works

1. **Register** — enter an employee's details, then the browser camera captures
   ~20 face samples. Each frame is detected, cropped to just the face, converted
   to grayscale, and saved to disk.
2. **Train** — after capture, the server automatically retrains an LBPH
   (Local Binary Patterns Histograms) face recognizer across every registered
   employee's samples. This happens in a few seconds, no restart needed.
3. **Recognize & log attendance** — on the attendance screen, the camera scans
   continuously (about once every ~1.8s). When a face is confidently matched,
   the system automatically records a check-in (first sighting of the day) or
   check-out (second sighting) with a timestamp.
4. **Dashboard & employee management** — view who's checked in today, and
   add/remove employees.

---

## Project structure

```
facial-attendance-system/
├── app.py                      # Flask app: all routes + API endpoints
├── config.py                   # Paths, thresholds, tunable settings
├── requirements.txt
├── Dockerfile                  # Container deploy (Render, Railway, Fly.io, etc.)
├── Procfile                    # Alternate deploy entrypoint (Render/Railway/Heroku-style)
├── database/
│   └── db_manager.py           # SQLite: employees + attendance tables
├── recognition/
│   ├── utils.py                # Base64 decode, Haar cascade face detection
│   ├── face_trainer.py         # Save face samples, (re)train LBPH model
│   └── face_recognizer.py      # Load model, recognize faces from frames
├── static/
│   ├── css/style.css           # UI styling (scanner/biometric theme)
│   └── js/
│       ├── register.js         # Camera capture flow for registration
│       └── attendance.js       # Live recognition polling loop
├── templates/                  # Jinja2 HTML pages
├── dataset/                    # Saved face images, one folder per employee (auto-created)
├── models/                     # trainer.yml — the trained LBPH model (auto-created)
└── attendance.db               # SQLite database (auto-created on first run)
```

---

## Running it locally

### 1. Requirements
- Python 3.9–3.12
- A webcam
- **A browser.** Camera access (`getUserMedia`) only works over `https://` or
  `http://localhost` — this is a browser security rule, not a bug in this app.
  Running on `localhost` (as below) satisfies this automatically.

### 2. Install dependencies

```bash
cd facial-attendance-system
pip install -r requirements.txt
```

> On Windows, if `pip install` ever hangs or errors on OpenCV, make sure you're
> using `opencv-contrib-python-headless` exactly as pinned in `requirements.txt` —
> it's a pure wheel with no compilation step.

### 3. Run the app

```bash
python app.py
```

Open **http://127.0.0.1:5000** in your browser (Chrome/Edge/Firefox all work).

### 4. Use it
1. Go to **Register Employee**, fill in the form, allow camera access, and let
   it capture 20 samples (move your head slightly for variety).
2. Once training finishes, go to **Mark Attendance** and look at the camera —
   it will recognize you and log a check-in.
3. Check the **Dashboard** to see today's attendance, or **Employees** to
   manage who's enrolled.

---

## Deploying (Render / Railway / any Docker host)

This project ships with both a `Dockerfile` and a `Procfile`, so it deploys
the same way your other projects have (Render.com, Railway, Fly.io):

**Option A — Docker:**
```bash
docker build -t facetrack .
docker run -p 5000:5000 facetrack
```

**Option B — Procfile (Render/Railway native Python runtime):**
Just push the repo; both platforms detect `Procfile` and `requirements.txt`
automatically. No extra configuration needed.

Both platforms provide **HTTPS by default**, so camera access works out of the
box in production — you do not need to configure SSL yourself.

### Important production note
`app.py`'s `if __name__ == "__main__"` block runs the Flask **development**
server, which is fine for local testing but not for production. The
`Dockerfile`/`Procfile` both use **gunicorn** instead — this is already wired
up for you, so you don't need to change anything to deploy correctly.

One gunicorn worker is used intentionally: the trained face model is cached in
each worker process's memory, and multiple workers would each hold a separate
copy that could go stale independently after a retrain. Concurrency is handled
with threads (`--threads 4`) instead of extra workers, which is enough for a
single-office attendance kiosk. If you need to scale to many simultaneous
kiosks, look into moving the trained model to shared storage (e.g. Redis) —
not required for typical use.

---

## Data storage — where the "identity database" lives

- **`attendance.db`** (SQLite) — two tables:
  - `employees`: employee_id, name, department, email, and a `label_id`
    (integer) that links a person to their trained face data.
  - `attendance`: one row per employee per day, with `check_in` / `check_out`
    timestamps.
- **`dataset/<label_id>/*.jpg`** — the actual face images captured during
  registration (cropped, grayscale, normalized). This is the raw "training
  data."
- **`models/trainer.yml`** — the trained LBPH model file. This is what
  actually gets compared against at recognition time; it is derived
  entirely from the images in `dataset/`.

Deleting an employee removes their row from both database tables, deletes
their `dataset/<label_id>/` folder, and retrains the model on whatever
remains — so no orphaned data or stale faces linger in the system.

---

## Tuning recognition accuracy

All in `config.py`:

| Setting | Meaning | Default |
|---|---|---|
| `IMAGES_PER_EMPLOYEE` | Samples captured per employee at registration | 20 |
| `CONFIDENCE_THRESHOLD` | Max LBPH distance to accept a match. **Lower = stricter.** Raise this if real employees are being rejected as "unknown"; lower it if strangers are being matched. | 75 |
| `MIN_FACE_SIZE` | Ignores detections smaller than this (filters false positives) | (80, 80) |
| `MIN_MINUTES_BETWEEN_CHECKIN_CHECKOUT` | Prevents an accidental check-out seconds after check-in | 1 |

If accuracy is inconsistent:
- Re-register in better, even lighting (avoid strong backlight).
- Increase `IMAGES_PER_EMPLOYEE` to 30 for people who look different day-to-day
  (glasses, facial hair, etc.) by capturing a mix of days.
- LBPH works well for a *small team* (tens of people). For hundreds of
  employees, matching accuracy will degrade — that's the natural ceiling of
  this lightweight approach versus deep embedding models (e.g. `face_recognition`/
  dlib or FaceNet), which trade easy deployment for heavier install requirements.

---

## Troubleshooting

**"Camera access denied or unavailable"**
Browser blocked camera permission, or you're on `http://` from a non-localhost
address (e.g. an IP address over plain HTTP). Use `https://` in production or
`localhost` locally.

**"No employees have been registered yet" when opening Mark Attendance**
Expected — register at least one employee first; the recognizer has nothing
to compare against otherwise.

**Registration keeps saying "No face detected"**
Check lighting, get closer to the camera, and make sure only one face is in
frame — the system deliberately refuses to save a sample if it sees zero or
more than one face, to avoid contaminating someone's training data.

**Windows: `use_reloader` / double camera init issues in debug mode**
Already handled — `app.run(..., use_reloader=False)` in `app.py`, matching the
fix used in your other Flask projects.

**Deploy fails with a libGL / X11 error**
Make sure `requirements.txt` still lists `opencv-contrib-python-headless`, not
plain `opencv-contrib-python`. The headless build has no GUI dependency and is
what avoids this exact class of container deployment failure.

---

## Security notes

- This uses face recognition to speed up *attendance logging*, not as a
  hardened authentication system — LBPH is a lightweight classical algorithm
  and can in principle be fooled by a printed photo held up to the camera. For
  a low-stakes office attendance kiosk this tradeoff is reasonable; it is not
  suitable for something like building access control without adding
  liveness detection.
- Face image data is biometric personal data. If you deploy this for real
  employees, let them know their photos are stored (in `dataset/`) and used
  only for attendance matching, and give them a way to be removed from the
  system (the **Employees → Remove** button deletes both their records and
  their stored face images).
