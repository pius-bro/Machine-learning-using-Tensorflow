export default function Message({ message, onQuickReply }) {
  const isBot = message.role === "bot";
  const time = new Date(message.timestamp).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <div className={`msg ${isBot ? "bot" : "user"}`}>
      <div className="bubble">{message.text}</div>
      <div className="msg-meta">
        {time}
        {isBot && message.intent && message.intent !== "unknown" && (
          <span className="intent-badge">⚡ {message.intent}</span>
        )}
        {isBot && message.escalated && (
          <span className="escalate-badge">👤 Escalated</span>
        )}
      </div>
      {isBot && message.suggested_actions?.length > 0 && (
        <div className="quick-replies" role="group" aria-label="Quick reply options">
          {message.suggested_actions.map((action) => (
            <button
              key={action}
              className="qr-btn"
              onClick={() => onQuickReply(action.replace(/^[^\w]+/, "").trim())}
            >
              {action}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
