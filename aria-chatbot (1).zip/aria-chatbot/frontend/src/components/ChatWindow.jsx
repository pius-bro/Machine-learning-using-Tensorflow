import { useState, useRef, useEffect } from "react";
import Message from "./Message";

export default function ChatWindow({ messages, isTyping, isConnected, onSend }) {
  const [input, setInput] = useState("");
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const handleSend = () => {
    if (!input.trim()) return;
    onSend(input.trim());
    setInput("");
  };

  return (
    <div className="chat-window">
      <header className="chat-header">
        <div className="bot-avatar" aria-hidden="true">🤖</div>
        <div>
          <div className="bot-name">Aria — AI Support</div>
          <div className={`bot-status ${isConnected ? "online" : "offline"}`}>
            <span className="status-dot" />
            {isConnected ? "Online" : "Reconnecting…"}
          </div>
        </div>
      </header>

      <div className="messages" role="log" aria-live="polite" aria-label="Conversation">
        {messages.map((msg) => (
          <Message key={msg.id} message={msg} onQuickReply={onSend} />
        ))}

        {isTyping && (
          <div className="msg bot" aria-label="Aria is typing">
            <div className="typing-indicator">
              <span /><span /><span />
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <div className="input-bar">
        <input
          className="chat-input"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          placeholder="Type a message…"
          aria-label="Type your message"
          disabled={!isConnected}
        />
        <button
          className="send-btn"
          onClick={handleSend}
          disabled={!isConnected || !input.trim()}
          aria-label="Send message"
        >
          ➤
        </button>
      </div>
    </div>
  );
}
