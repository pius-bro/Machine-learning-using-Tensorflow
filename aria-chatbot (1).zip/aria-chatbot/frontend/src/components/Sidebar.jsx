export default function Sidebar({ isConnected, sessionId, nlpResult, analytics }) {
  const confPct = nlpResult ? Math.round(nlpResult.confidence * 100) : 0;
  const confColor =
    confPct >= 70 ? "#22c55e" : confPct >= 45 ? "#f59e0b" : "#ef4444";

  return (
    <div className="sidebar-inner">
      <div className="sidebar-logo">🤖 Aria Chatbot</div>
      <div className="sidebar-section">
        <div className="sidebar-label">Connection</div>
        <div className={`connection-status ${isConnected ? "connected" : "disconnected"}`}>
          <span className="conn-dot" />
          {isConnected ? "WebSocket connected" : "Disconnected"}
        </div>
        <div className="session-id">Session: {sessionId.slice(0, 8)}…</div>
      </div>

      {nlpResult && (
        <div className="sidebar-section">
          <div className="sidebar-label">Last NLP Result</div>
          <div className="nlp-card">
            <div className="nlp-row">
              <span className="nlp-key">Intent</span>
              <span className="nlp-val intent-tag">{nlpResult.intent}</span>
            </div>
            <div className="nlp-row">
              <span className="nlp-key">Confidence</span>
              <span className="nlp-val" style={{ color: confColor }}>
                {confPct}%
              </span>
            </div>
            <div className="conf-bar">
              <div
                className="conf-fill"
                style={{ width: `${confPct}%`, background: confColor }}
              />
            </div>
            <div className="nlp-row">
              <span className="nlp-key">Sentiment</span>
              <span className="nlp-val">
                {nlpResult.sentiment === "positive" ? "😊" :
                 nlpResult.sentiment === "negative" ? "😟" : "😐"}{" "}
                {nlpResult.sentiment}
              </span>
            </div>
            {Object.keys(nlpResult.entities || {}).length > 0 && (
              <div className="entity-list">
                <div className="nlp-key" style={{ marginBottom: 4 }}>Entities</div>
                {Object.entries(nlpResult.entities).map(([k, v]) => (
                  <div key={k} className="entity-chip">
                    <span className="entity-key">{k}</span>
                    <span className="entity-val">{String(v)}</span>
                  </div>
                ))}
              </div>
            )}
            {nlpResult.escalated && (
              <div className="escalate-notice">⚠️ Escalated to human agent</div>
            )}
          </div>
        </div>
      )}

      {analytics && (
        <div className="sidebar-section">
          <div className="sidebar-label">Live Analytics</div>
          <div className="analytics-grid">
            <div className="stat-card">
              <div className="stat-val">{analytics.total_sessions}</div>
              <div className="stat-lbl">Sessions</div>
            </div>
            <div className="stat-card">
              <div className="stat-val">{analytics.total_turns}</div>
              <div className="stat-lbl">Turns</div>
            </div>
            <div className="stat-card">
              <div className="stat-val">{analytics.escalated_sessions}</div>
              <div className="stat-lbl">Escalated</div>
            </div>
            <div className="stat-card">
              <div className="stat-val">{analytics.avg_turns_per_session}</div>
              <div className="stat-lbl">Avg turns</div>
            </div>
          </div>
        </div>
      )}

      <div className="sidebar-section">
        <div className="sidebar-label">NLP Stack</div>
        <div className="stack-list">
          <div className="stack-item">🧠 spaCy — tokenization & NER</div>
          <div className="stack-item">🎯 BERT — intent classification</div>
          <div className="stack-item">📚 RAG — knowledge retrieval</div>
          <div className="stack-item">✨ Claude / GPT-4o — generation</div>
          <div className="stack-item">⚡ FastAPI — WebSocket backend</div>
        </div>
      </div>
    </div>
  );
}
