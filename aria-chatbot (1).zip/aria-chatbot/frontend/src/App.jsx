import { useState, useEffect, useRef, useCallback } from "react";
import { v4 as uuidv4 } from "uuid";
import ChatWindow from "./components/ChatWindow";
import Sidebar from "./components/Sidebar";
import "./App.css";

const WS_URL = import.meta.env.VITE_WS_URL || "ws://localhost:8000";

export default function App() {
  const [messages, setMessages] = useState([]);
  const [isConnected, setIsConnected] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [sessionId] = useState(() => uuidv4());
  const [analytics, setAnalytics] = useState(null);
  const [lastNlpResult, setLastNlpResult] = useState(null);
  const wsRef = useRef(null);

  const connect = useCallback(() => {
    const ws = new WebSocket(`${WS_URL}/ws/${sessionId}`);

    ws.onopen = () => {
      setIsConnected(true);
      console.log("WebSocket connected:", sessionId);
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);

      if (data.type === "typing") {
        setIsTyping(true);
        return;
      }

      setIsTyping(false);

      if (data.type === "bot_message") {
        setMessages((prev) => [...prev, { ...data, role: "bot" }]);
        setLastNlpResult({
          intent: data.intent,
          confidence: data.confidence,
          entities: data.entities,
          sentiment: data.sentiment,
          escalated: data.escalated,
        });
      }
    };

    ws.onclose = () => {
      setIsConnected(false);
      // Auto-reconnect after 3 seconds
      setTimeout(connect, 3000);
    };

    ws.onerror = (err) => {
      console.error("WebSocket error:", err);
      ws.close();
    };

    wsRef.current = ws;
  }, [sessionId]);

  useEffect(() => {
    connect();
    return () => wsRef.current?.close();
  }, [connect]);

  // Poll analytics every 30 seconds
  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const res = await fetch("http://localhost:8000/api/v1/analytics/overview");
        if (res.ok) setAnalytics(await res.json());
      } catch {
        /* backend might not be running yet */
      }
    };
    fetchAnalytics();
    const interval = setInterval(fetchAnalytics, 30000);
    return () => clearInterval(interval);
  }, []);

  const sendMessage = useCallback((text) => {
    if (!text.trim() || !wsRef.current) return;

    // Optimistically add user message
    setMessages((prev) => [
      ...prev,
      {
        id: uuidv4(),
        role: "user",
        text,
        timestamp: new Date().toISOString(),
      },
    ]);

    wsRef.current.send(JSON.stringify({ message: text, session_id: sessionId }));
  }, [sessionId]);

  return (
    <div className="app-layout">
      <aside className="sidebar">
        <Sidebar
          isConnected={isConnected}
          sessionId={sessionId}
          nlpResult={lastNlpResult}
          analytics={analytics}
        />
      </aside>
      <main className="chat-area">
        <ChatWindow
          messages={messages}
          isTyping={isTyping}
          isConnected={isConnected}
          onSend={sendMessage}
        />
      </main>
    </div>
  );
}
