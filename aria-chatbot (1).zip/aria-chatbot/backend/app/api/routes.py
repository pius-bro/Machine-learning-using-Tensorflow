"""REST API routes for session management, analytics, and admin."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from datetime import datetime

router = APIRouter()

# In-memory store (replace with PostgreSQL in production)
_sessions_ref = {}


class FeedbackPayload(BaseModel):
    session_id: str
    turn_id: int
    rating: int           # 1-5
    comment: str = ""


@router.get("/sessions/{session_id}/history")
async def get_conversation_history(session_id: str):
    """Return full conversation history for a session."""
    from app.main import chat_service
    history = chat_service.get_session_history(session_id)
    if not history:
        raise HTTPException(status_code=404, detail="Session not found")
    return {"session_id": session_id, "turns": history}


@router.get("/analytics/overview")
async def get_analytics():
    """Return aggregate chatbot performance stats."""
    from app.main import chat_service
    stats = chat_service.get_all_sessions_stats()
    return {
        **stats,
        "timestamp": datetime.utcnow().isoformat(),
        "nlp_model": "rule-based + optional spaCy/BERT",
        "uptime_seconds": 0,
    }


@router.post("/feedback")
async def submit_feedback(payload: FeedbackPayload):
    """Log user feedback for a specific bot turn (used for retraining)."""
    # In production: write to PostgreSQL feedback table
    return {
        "status": "received",
        "session_id": payload.session_id,
        "turn_id": payload.turn_id,
        "rating": payload.rating,
    }


@router.get("/intents")
async def list_intents():
    """List all supported intents and their pattern count."""
    from app.nlp.pipeline import NLPPipeline
    pipeline = NLPPipeline()
    return {
        "intents": [
            {"name": intent, "pattern_count": len(patterns)}
            for intent, patterns in pipeline.INTENT_PATTERNS.items()
        ]
    }


@router.post("/nlp/test")
async def test_nlp(payload: dict):
    """Test the NLP pipeline with a raw message. Useful for debugging."""
    from app.nlp.pipeline import NLPPipeline
    text = payload.get("text", "")
    if not text:
        raise HTTPException(status_code=400, detail="'text' field required")
    pipeline = NLPPipeline()
    result = pipeline.process(text)
    return {
        "input": text,
        "tokens": result.tokens,
        "intent": result.intent,
        "confidence": result.confidence,
        "entities": result.entities,
        "sentiment": result.sentiment,
        "response": result.response,
        "should_escalate": result.should_escalate,
    }
