"""
NLP Pipeline
Stages: Preprocessing → Intent Classification → NER → Response Generation
Uses spaCy for NLP, scikit-learn for intent classification,
and OpenAI/Anthropic API for LLM response generation.
"""
import re
import json
import logging
from dataclasses import dataclass, field
from typing import Optional
import os

logger = logging.getLogger(__name__)


@dataclass
class NLPResult:
    text: str
    tokens: list[str] = field(default_factory=list)
    intent: str = "unknown"
    confidence: float = 0.0
    entities: dict = field(default_factory=dict)
    sentiment: str = "neutral"
    response: str = ""
    should_escalate: bool = False
    suggested_actions: list[str] = field(default_factory=list)


class NLPPipeline:
    """
    Multi-stage NLP pipeline for chatbot understanding.
    Falls back gracefully if optional models are not installed.
    """

    INTENT_PATTERNS = {
        "order_tracking": [
            r"\border\b", r"\btrack\b", r"\bwhere.*(my|is)\b",
            r"\bshipping\b", r"\bdelivery\b", r"\bstatus\b",
        ],
        "return_product": [
            r"\breturn\b", r"\brefund\b", r"\bexchange\b",
            r"\bsend back\b", r"\bwant.*back\b",
        ],
        "damaged_item": [
            r"\bdamaged\b", r"\bbroken\b", r"\bdefective\b",
            r"\bnot working\b", r"\bdoesn.t work\b", r"\bbroken\b",
        ],
        "billing_query": [
            r"\bcharge\b", r"\bbill\b", r"\binvoice\b",
            r"\bpayment\b", r"\bprice\b", r"\bcost\b",
        ],
        "product_info": [
            r"\bwhat is\b", r"\btell me about\b", r"\bdoes it\b",
            r"\bfeatures\b", r"\bspec\b", r"\bhow does\b",
        ],
        "human_handoff": [
            r"\bhuman\b", r"\bagent\b", r"\bperson\b",
            r"\bspeak to\b", r"\btalk to\b", r"\bsupport team\b",
        ],
        "complaint": [
            r"\bterrible\b", r"\bawful\b", r"\bdisappointed\b",
            r"\bunacceptable\b", r"\bfrustrat\b", r"\bangry\b",
        ],
        "greeting": [
            r"\bhello\b", r"\bhi\b", r"\bhey\b",
            r"\bgood morning\b", r"\bgood afternoon\b",
        ],
        "goodbye": [
            r"\bbye\b", r"\bgoodbye\b", r"\bthanks?\b",
            r"\bthank you\b", r"\bsee you\b",
        ],
    }

    ENTITY_PATTERNS = {
        "order_id": r"\b([A-Z]{2,3}-?\d{4,8}|#\d{4,8})\b",
        "email": r"\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b",
        "product": r"\b(laptop|phone|tablet|headphones?|keyboard|mouse|monitor|charger|cable)\b",
        "amount": r"\$\d+(?:\.\d{2})?",
        "date": r"\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|today|yesterday|last week)\b",
    }

    RESPONSE_TEMPLATES = {
        "order_tracking": [
            "I'd be happy to track your order! Could you please provide your order number (e.g. ORD-12345)?",
            "Let me look that up for you. What's your order ID?",
        ],
        "return_product": [
            "I can help you with a return. Our return window is 30 days from delivery. "
            "Do you have your order number handy?",
            "Sure! Returns are easy. Please share your order ID and I'll get the process started.",
        ],
        "damaged_item": [
            "I'm really sorry to hear your item arrived damaged — that's not acceptable. "
            "We'll make this right with a replacement or full refund. Can you share your order number?",
        ],
        "billing_query": [
            "I can help with billing questions. Could you share more details about the charge "
            "or invoice you're enquiring about?",
        ],
        "product_info": [
            "Great question! I can pull up product details for you. Which product are you interested in?",
        ],
        "human_handoff": [
            "Of course! I'm connecting you with a human support agent right now. "
            "Typical wait time is 2–3 minutes. Please hold.",
        ],
        "complaint": [
            "I'm truly sorry to hear about your experience. Your feedback matters and we want to make this right. "
            "Could you tell me more so I can help resolve this quickly?",
        ],
        "greeting": [
            "Hello! 👋 I'm Aria, your AI support assistant. How can I help you today?",
            "Hi there! Welcome. What can I assist you with?",
        ],
        "goodbye": [
            "Thank you for chatting with us! Have a great day. 😊",
            "Glad I could help! Don't hesitate to reach out anytime.",
        ],
        "unknown": [
            "I want to make sure I understand you correctly. Could you rephrase that? "
            "Or I can connect you with a human agent who can help further.",
            "I'm not quite sure I caught that. Could you tell me more about what you need?",
        ],
    }

    ESCALATION_THRESHOLD = 0.45

    def __init__(self):
        self.nlp = None
        self._load_spacy()

    def _load_spacy(self):
        try:
            import spacy
            try:
                self.nlp = spacy.load("en_core_web_sm")
                logger.info("spaCy model loaded: en_core_web_sm")
            except OSError:
                logger.warning(
                    "spaCy model not found. Run: python -m spacy download en_core_web_sm"
                )
        except ImportError:
            logger.warning("spaCy not installed. Using rule-based NLP only.")

    def preprocess(self, text: str) -> list[str]:
        """Lowercase, strip punctuation, basic tokenize."""
        text = text.lower().strip()
        text = re.sub(r"[^\w\s]", " ", text)
        tokens = [t for t in text.split() if len(t) > 1]
        return tokens

    def classify_intent(self, text: str) -> tuple[str, float]:
        """
        Rule-based intent classification with confidence scoring.
        Replace with a fine-tuned BERT model for production.
        """
        text_lower = text.lower()
        scores = {}

        for intent, patterns in self.INTENT_PATTERNS.items():
            matches = sum(
                1 for p in patterns if re.search(p, text_lower, re.IGNORECASE)
            )
            if matches:
                scores[intent] = min(0.5 + (matches * 0.15), 0.98)

        if not scores:
            return "unknown", 0.3

        best_intent = max(scores, key=scores.get)
        return best_intent, scores[best_intent]

    def extract_entities(self, text: str) -> dict:
        """Extract named entities using regex + optional spaCy NER."""
        entities = {}

        for entity_type, pattern in self.ENTITY_PATTERNS.items():
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                entities[entity_type] = matches[0] if len(matches) == 1 else matches

        # Augment with spaCy NER if available
        if self.nlp:
            doc = self.nlp(text)
            for ent in doc.ents:
                if ent.label_ in ("PERSON", "ORG", "GPE", "DATE", "MONEY"):
                    entities[ent.label_.lower()] = ent.text

        return entities

    def analyze_sentiment(self, text: str) -> str:
        """Simple lexicon-based sentiment. Swap for a transformer model."""
        positive = ["great", "good", "thanks", "excellent", "happy", "love", "perfect"]
        negative = ["bad", "terrible", "awful", "broken", "damaged", "angry", "frustrated", "worst"]

        text_lower = text.lower()
        pos = sum(1 for w in positive if w in text_lower)
        neg = sum(1 for w in negative if w in text_lower)

        if neg > pos:
            return "negative"
        elif pos > neg:
            return "positive"
        return "neutral"

    def generate_response(self, intent: str, entities: dict, confidence: float) -> tuple[str, list[str]]:
        """
        Select response template. In production, replace with LLM call
        (see app/services/llm_service.py for OpenAI/Anthropic integration).
        """
        import random

        templates = self.RESPONSE_TEMPLATES.get(intent, self.RESPONSE_TEMPLATES["unknown"])
        response = random.choice(templates)

        # Personalise with extracted entities
        if "order_id" in entities:
            response += f" I can see you're referencing order {entities['order_id']}."
        if "product" in entities:
            response = response.replace("item", entities["product"]).replace("product", entities["product"])

        # Suggest quick actions based on intent
        action_map = {
            "order_tracking": ["📦 Track order", "📞 Call support"],
            "return_product": ["↩️ Start return", "📸 Upload photo"],
            "damaged_item": ["📸 Upload photo", "🔄 Get replacement", "💰 Request refund"],
            "billing_query": ["🧾 View invoice", "📞 Billing team"],
            "human_handoff": ["👤 Connect now", "📅 Schedule call"],
            "greeting": ["📦 Track order", "↩️ Returns", "❓ FAQs"],
        }
        actions = action_map.get(intent, ["❓ FAQs", "👤 Human agent"])

        return response, actions

    def process(self, text: str) -> NLPResult:
        """Run the full NLP pipeline on a user message."""
        result = NLPResult(text=text)

        result.tokens = self.preprocess(text)
        result.intent, result.confidence = self.classify_intent(text)
        result.entities = self.extract_entities(text)
        result.sentiment = self.analyze_sentiment(text)
        result.should_escalate = result.confidence < self.ESCALATION_THRESHOLD
        result.response, result.suggested_actions = self.generate_response(
            result.intent, result.entities, result.confidence
        )

        if result.should_escalate:
            result.response = (
                "I want to make sure you get the best help. "
                "Let me connect you with a specialist. "
                + result.response
            )

        logger.info(
            f"NLP | intent={result.intent} conf={result.confidence:.2f} "
            f"entities={result.entities} sentiment={result.sentiment}"
        )

        return result
