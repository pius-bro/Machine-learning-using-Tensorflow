"""Pydantic schemas for request/response validation."""
from pydantic import BaseModel
from typing import Optional


class MessageIn(BaseModel):
    message: str
    session_id: Optional[str] = None


class MessageOut(BaseModel):
    type: str
    id: str
    session_id: str
    text: str
    intent: str
    confidence: float
    entities: dict
    sentiment: str
    suggested_actions: list[str]
    escalated: bool
    turn: int
    timestamp: str
