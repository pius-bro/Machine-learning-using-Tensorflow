"""
Chat Service
Orchestrates: session management, NLP pipeline, conversation history,
LLM fallback, and human escalation.
"""
import uuid
import logging
from datetime import datetime
from typing import Optional
from collections import defaultdict

from app.nlp.pipeline import NLPPipeline, NLPResult

logger = logging.getLogger(__name__)


class ConversationSession:
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.created_at = datetime.utcnow()
        self.history: list[dict] = []
        self.context: dict = {}   # slot-fill store (order_id, product, etc.)
        self.is_escalated = False
        self.turn_count = 0

    def add_turn(self, user_msg: str, bot_response: str, nlp_result: NLPResult):
        self.history.append({
            "turn": self.turn_count,
            "timestamp": datetime.utcnow().isoformat(),
            "user": user_msg,
            "bot": bot_response,
            "intent": nlp_result.intent,
            "confidence": nlp_result.confidence,
            "entities": nlp_result.entities,
            "sentiment": nlp_result.sentiment,
        })
        # Accumulate entities into session context (slot filling)
        self.context.update(nlp_result.entities)
        self.turn_count += 1


class ChatService:
    def __init__(self):
        self.pipeline: Optional[NLPPipeline] = None
        self.sessions: dict[str, ConversationSession] = defaultdict(lambda: None)
        self.models_ready = False

    async def load_nlp_models(self):
        """Load NLP models at startup."""
        try:
            self.pipeline = NLPPipeline()
            self.models_ready = True
            logger.info("ChatService: NLP pipeline ready")
        except Exception as e:
            logger.error(f"Failed to load NLP models: {e}")
            self.models_ready = False

    def _get_or_create_session(self, session_id: str) -> ConversationSession:
        if session_id not in self.sessions or self.sessions[session_id] is None:
            self.sessions[session_id] = ConversationSession(session_id)
        return self.sessions[session_id]

    async def get_welcome_message(self, session_id: str) -> dict:
        """Send initial greeting when a user connects."""
        self._get_or_create_session(session_id)
        return {
            "type": "bot_message",
            "id": str(uuid.uuid4()),
            "session_id": session_id,
            "text": "Hello! I'm Aria, your AI support assistant. 👋 How can I help you today?",
            "intent": "greeting",
            "confidence": 1.0,
            "suggested_actions": ["📦 Track order", "↩️ Return product", "❓ FAQs", "👤 Human agent"],
            "timestamp": datetime.utcnow().isoformat(),
        }

    async def process_message(self, session_id: str, message: str) -> dict:
        """
        Full message processing:
        1. Retrieve/create session
        2. Run NLP pipeline
        3. Check escalation
        4. Store history
        5. Return structured response
        """
        session = self._get_or_create_session(session_id)

        if not self.pipeline:
            return self._error_response(session_id, "NLP service unavailable. Please try again shortly.")

        # Run NLP pipeline
        nlp_result: NLPResult = self.pipeline.process(message)

        # Check if already escalated to human
        if session.is_escalated:
            nlp_result.response = (
                "You're currently connected with our support team. "
                "A human agent will respond shortly."
            )
            nlp_result.suggested_actions = []

        # Mark session as escalated if needed
        if nlp_result.intent == "human_handoff" or nlp_result.should_escalate:
            session.is_escalated = True

        # Store turn in history
        session.add_turn(message, nlp_result.response, nlp_result)

        return {
            "type": "bot_message",
            "id": str(uuid.uuid4()),
            "session_id": session_id,
            "text": nlp_result.response,
            "intent": nlp_result.intent,
            "confidence": round(nlp_result.confidence, 2),
            "entities": nlp_result.entities,
            "sentiment": nlp_result.sentiment,
            "suggested_actions": nlp_result.suggested_actions,
            "escalated": session.is_escalated,
            "turn": session.turn_count,
            "timestamp": datetime.utcnow().isoformat(),
        }

    def get_session_history(self, session_id: str) -> list[dict]:
        session = self.sessions.get(session_id)
        if not session:
            return []
        return session.history

    def get_all_sessions_stats(self) -> dict:
        total = len(self.sessions)
        escalated = sum(1 for s in self.sessions.values() if s and s.is_escalated)
        total_turns = sum(s.turn_count for s in self.sessions.values() if s)
        return {
            "total_sessions": total,
            "escalated_sessions": escalated,
            "total_turns": total_turns,
            "avg_turns_per_session": round(total_turns / max(total, 1), 1),
        }

    def _error_response(self, session_id: str, message: str) -> dict:
        return {
            "type": "error",
            "session_id": session_id,
            "text": message,
            "timestamp": datetime.utcnow().isoformat(),
        }
