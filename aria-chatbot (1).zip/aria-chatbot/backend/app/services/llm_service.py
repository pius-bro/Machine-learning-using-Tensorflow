"""
LLM Service
Integrates OpenAI GPT-4o and Anthropic Claude for production-grade
response generation with RAG context injection.

Set environment variables:
  OPENAI_API_KEY   — for GPT-4o
  ANTHROPIC_API_KEY — for Claude

Only one is required. The service tries Anthropic first, then OpenAI.
"""
import os
import logging
from typing import Optional

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are Aria, a helpful and empathetic AI customer support assistant.
Your job is to:
- Help customers with order tracking, returns, billing, and product questions
- Be concise, friendly, and solution-focused
- Ask for order numbers / account details when needed
- Escalate to a human agent if the customer is very upset or the issue is complex
- Never make up order statuses or policies you don't know

Always respond in 1-3 sentences unless a detailed explanation is required.
"""


async def generate_llm_response(
    user_message: str,
    conversation_history: list[dict],
    context: dict,
    intent: str,
    entities: dict,
) -> Optional[str]:
    """
    Generate a response using an LLM with conversation history and entity context.
    Falls back to None if no API key is configured (pipeline uses templates instead).
    """

    # Build messages list from history
    messages = []
    for turn in conversation_history[-6:]:  # last 6 turns = 12 messages
        messages.append({"role": "user", "content": turn["user"]})
        messages.append({"role": "assistant", "content": turn["bot"]})
    messages.append({"role": "user", "content": user_message})

    # Add context as a system addendum
    context_note = ""
    if entities:
        context_note = f"\n\nExtracted context: {entities}"
    if context:
        context_note += f"\nSession context (slot fill): {context}"

    # Try Anthropic Claude first
    anthropic_key = os.getenv("ANTHROPIC_API_KEY")
    if anthropic_key:
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=anthropic_key)
            response = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=300,
                system=SYSTEM_PROMPT + context_note,
                messages=messages,
            )
            return response.content[0].text
        except Exception as e:
            logger.error(f"Anthropic API error: {e}")

    # Fallback to OpenAI
    openai_key = os.getenv("OPENAI_API_KEY")
    if openai_key:
        try:
            from openai import AsyncOpenAI
            client = AsyncOpenAI(api_key=openai_key)
            response = await client.chat.completions.create(
                model="gpt-4o-mini",
                max_tokens=300,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT + context_note},
                    *messages,
                ],
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"OpenAI API error: {e}")

    logger.warning("No LLM API key configured. Using template responses.")
    return None
