"""WebSocket connection manager — tracks all active sessions."""
import json
import logging
from fastapi import WebSocket

logger = logging.getLogger(__name__)


class ConnectionManager:
    def __init__(self):
        self.active_connections: dict[str, WebSocket] = {}

    async def connect(self, websocket: WebSocket, session_id: str):
        await websocket.accept()
        self.active_connections[session_id] = websocket
        logger.info(f"Active connections: {len(self.active_connections)}")

    def disconnect(self, session_id: str):
        self.active_connections.pop(session_id, None)

    async def send_message(self, message: dict, session_id: str):
        ws = self.active_connections.get(session_id)
        if ws:
            await ws.send_text(json.dumps(message))

    async def broadcast(self, message: dict):
        for session_id, ws in self.active_connections.items():
            try:
                await ws.send_text(json.dumps(message))
            except Exception as e:
                logger.error(f"Broadcast error for {session_id}: {e}")

    @property
    def connection_count(self) -> int:
        return len(self.active_connections)
