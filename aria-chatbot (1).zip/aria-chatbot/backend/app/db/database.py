"""
Database layer.
Uses SQLite locally (zero config), PostgreSQL in production.
Set DATABASE_URL env var to switch: postgresql://user:pass@host/db
"""
import os
import logging
import aiosqlite

logger = logging.getLogger(__name__)

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./chatbot.db")
DB_PATH = "chatbot.db"

CREATE_TABLES_SQL = """
CREATE TABLE IF NOT EXISTS conversations (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  TEXT NOT NULL,
    turn        INTEGER NOT NULL,
    user_msg    TEXT NOT NULL,
    bot_msg     TEXT NOT NULL,
    intent      TEXT,
    confidence  REAL,
    entities    TEXT,
    sentiment   TEXT,
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS feedback (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  TEXT NOT NULL,
    turn_id     INTEGER NOT NULL,
    rating      INTEGER NOT NULL,
    comment     TEXT,
    created_at  TEXT NOT NULL
);
"""


async def init_db():
    """Create tables on startup."""
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            await db.executescript(CREATE_TABLES_SQL)
            await db.commit()
        logger.info(f"Database ready: {DB_PATH}")
    except Exception as e:
        logger.error(f"Database init failed: {e}")


async def save_turn(session_id: str, turn: dict):
    """Persist a conversation turn."""
    import json
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """INSERT INTO conversations
               (session_id, turn, user_msg, bot_msg, intent, confidence, entities, sentiment, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                session_id,
                turn.get("turn", 0),
                turn.get("user", ""),
                turn.get("bot", ""),
                turn.get("intent"),
                turn.get("confidence"),
                json.dumps(turn.get("entities", {})),
                turn.get("sentiment"),
                turn.get("timestamp", ""),
            ),
        )
        await db.commit()
