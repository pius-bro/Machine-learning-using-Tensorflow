"""
Production-ready FastAPI backend
Adds: rate limiting, structured logging, security headers, CORS lockdown
"""
import os
import time
import logging
import uuid
from contextlib import asynccontextmanager
from collections import defaultdict

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import json
from datetime import datetime

from app.api.routes import router as api_router
from app.services.connection_manager import ConnectionManager
from app.services.chat_service import ChatService
from app.db.database import init_db

# ── Logging ──────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)

# ── App state ─────────────────────────────────────────────────
manager = ConnectionManager()
chat_service = ChatService()

# ── Rate limiter (simple in-memory; use Redis in multi-instance prod) ──
_rate_store: dict[str, list[float]] = defaultdict(list)
RATE_LIMIT = 30       # max messages per window
RATE_WINDOW = 60      # seconds


def is_rate_limited(client_ip: str) -> bool:
    now = time.time()
    window_start = now - RATE_WINDOW
    hits = [t for t in _rate_store[client_ip] if t > window_start]
    _rate_store[client_ip] = hits
    if len(hits) >= RATE_LIMIT:
        return True
    _rate_store[client_ip].append(now)
    return False


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 Starting Aria AI Chatbot (production mode)...")
    await init_db()
    await chat_service.load_nlp_models()
    logger.info("✅ NLP models loaded — server ready")
    yield
    logger.info("🛑 Shutting down...")


# ── App ───────────────────────────────────────────────────────
app = FastAPI(
    title="Aria AI Chatbot API",
    version="1.0.0",
    docs_url="/docs" if os.getenv("APP_ENV") != "production" else None,
    redoc_url=None,
    lifespan=lifespan,
)

# ── CORS — lock to your real domain in production ─────────────
ALLOWED_ORIGINS = os.getenv(
    "ALLOWED_ORIGINS",
    "http://localhost:3000,http://localhost:5173"
).split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

# ── Security headers middleware ────────────────────────────────
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Strict-Transport-Security"] = "max-age=31536000"
    return response

# ── Request logging middleware ────────────────────────────────
@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    duration = round((time.time() - start) * 1000, 1)
    logger.info(f"{request.method} {request.url.path} → {response.status_code} ({duration}ms)")
    return response


app.include_router(api_router, prefix="/api/v1")


@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "env": os.getenv("APP_ENV", "development"),
        "models_ready": chat_service.models_ready,
        "active_connections": manager.connection_count,
        "timestamp": datetime.utcnow().isoformat(),
    }


@app.websocket("/ws/{session_id}")
async def websocket_endpoint(websocket: WebSocket, session_id: str):
    client_ip = websocket.client.host if websocket.client else "unknown"

    # Validate session_id format
    try:
        uuid.UUID(session_id)
    except ValueError:
        await websocket.close(code=4000)
        return

    await manager.connect(websocket, session_id)
    logger.info(f"WS connected: {session_id} from {client_ip}")

    try:
        welcome = await chat_service.get_welcome_message(session_id)
        await manager.send_message(welcome, session_id)

        while True:
            raw = await websocket.receive_text()

            # Rate limit check
            if is_rate_limited(client_ip):
                await manager.send_message({
                    "type": "error",
                    "text": "Too many messages. Please wait a moment.",
                    "session_id": session_id,
                }, session_id)
                continue

            # Input validation
            try:
                data = json.loads(raw)
                message = str(data.get("message", "")).strip()
            except Exception:
                continue

            if not message or len(message) > 1000:
                continue

            # Typing indicator
            await manager.send_message({"type": "typing", "session_id": session_id}, session_id)

            # Process and respond
            response = await chat_service.process_message(
                session_id=session_id,
                message=message,
            )
            await manager.send_message(response, session_id)

    except WebSocketDisconnect:
        manager.disconnect(session_id)
        logger.info(f"WS disconnected: {session_id}")
    except Exception as e:
        logger.error(f"WS error {session_id}: {e}")
        manager.disconnect(session_id)
