# 🤖 Aria — AI Chatbot

Full-stack AI chatbot · FastAPI backend · React frontend · NLP pipeline · Production-ready

---

## 📁 Project Structure

```
aria-chatbot/
│
├── 🐍 backend/                        # FastAPI Python server
│   ├── app/
│   │   ├── main.py                    # App entry + WebSocket endpoint
│   │   ├── api/routes.py              # REST endpoints
│   │   ├── nlp/pipeline.py            # NLP: tokenize → intent → NER → respond
│   │   ├── services/
│   │   │   ├── chat_service.py        # Session + conversation logic
│   │   │   ├── connection_manager.py  # WebSocket manager
│   │   │   └── llm_service.py         # Claude / GPT-4o integration
│   │   └── db/database.py             # SQLite (local) / PostgreSQL (prod)
│   ├── requirements.txt
│   ├── Dockerfile                     # Production Docker image
│   ├── railway.json                   # Railway deployment config
│   └── .env.example                   # Copy to .env, add your API keys
│
├── ⚛️  frontend/                       # React + Vite chat UI
│   ├── src/
│   │   ├── App.jsx                    # Root + WebSocket client
│   │   ├── App.css                    # Full chat styling
│   │   └── components/
│   │       ├── ChatWindow.jsx          # Messages + input bar
│   │       ├── Message.jsx             # Bubble + quick replies
│   │       └── Sidebar.jsx             # Live NLP debug panel
│   ├── package.json
│   └── .env.example                   # Copy to .env, set WS URL
│
├── ⚙️  scripts/
│   ├── start_local.sh                 # ONE COMMAND to run locally
│   ├── start_docker.sh                # Run with Docker locally
│   └── setup_vps.sh                   # One-command VPS server setup
│
├── 🌐 nginx/nginx.conf                # Production reverse proxy + SSL
├── 🐳 docker-compose.yml              # Local Docker stack
├── 🐳 docker-compose.prod.yml         # Production Docker stack
├── 📦 render.yaml                     # Render.com deployment
├── 🔐 .env.production                 # Production env template
└── 🤖 .github/workflows/deploy.yml   # Auto-deploy CI/CD pipeline
```

---

## 🚀 Run Locally

**Requirements:** Python 3.11+ and Node.js 18+

### Mac / Linux — one command
```bash
chmod +x scripts/start_local.sh
./scripts/start_local.sh
```

### Windows / Manual

**Terminal 1 — Backend:**
```bash
cd backend
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # Mac/Linux
pip install -r requirements.txt
python -m spacy download en_core_web_sm
cp .env.example .env
uvicorn app.main:app --reload --port 8000
```

**Terminal 2 — Frontend:**
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

| What | URL |
|---|---|
| Chat UI | http://localhost:3000 |
| API Docs | http://localhost:8000/docs |
| Health | http://localhost:8000/health |

---

## 🔑 Add LLM API Key (optional but recommended)

Edit `backend/.env`:
```env
ANTHROPIC_API_KEY=sk-ant-your-key-here
```
Get your key at console.anthropic.com (free tier available).

---

## 🌍 Deploy to Production

### Railway + Vercel (recommended, ~10 min)
```bash
# Push to GitHub first
git init && git add . && git commit -m "initial commit"
git remote add origin https://github.com/YOUR_NAME/aria-chatbot.git
git push -u origin main
```
Then: railway.app → New Project → your repo → root: `backend`
Then: vercel.com → Import → your repo → root: `frontend` → set `VITE_WS_URL=wss://your-railway-url`

### Render (free tier)
render.yaml is in the root — connect repo on render.com → New → Blueprint

### VPS (full control)
```bash
bash scripts/setup_vps.sh yourdomain.com https://github.com/YOUR_NAME/aria-chatbot.git
```

---

## 🔐 Security checklist before going live
- [ ] API keys in `backend/.env` only — never in code
- [ ] `.env` is in `.gitignore` (already set)
- [ ] Frontend uses `wss://` not `ws://` in production
- [ ] Set `ALLOWED_ORIGINS` to your real domain
