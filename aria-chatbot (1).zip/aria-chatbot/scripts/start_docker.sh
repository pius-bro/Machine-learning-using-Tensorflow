#!/usr/bin/env bash
# Start everything with Docker Compose
set -e

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "Building and starting AI Chatbot with Docker..."
echo ""

# Copy .env if missing
if [ ! -f ".env" ]; then
  cat > .env << 'EOF'
# Add your API keys here for LLM-powered responses (optional)
ANTHROPIC_API_KEY=
OPENAI_API_KEY=
EOF
  echo "Created .env — add API keys to enable LLM responses"
fi

docker compose up --build

echo ""
echo "Chatbot running at http://localhost:3000"
echo "API docs at      http://localhost:8000/docs"
