#!/usr/bin/env bash
# ─────────────────────────────────────────────
#  Aria Chatbot — Local Development Startup
#  Starts backend + frontend with one command
# ─────────────────────────────────────────────
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "${BLUE}╔══════════════════════════════════╗${NC}"
echo -e "${BLUE}║   Aria Chatbot — Local Start     ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════╝${NC}"

# Check tools
command -v python3 &>/dev/null || { echo "Python 3 required. Install from python.org"; exit 1; }
command -v node    &>/dev/null || { echo "Node.js required. Install from nodejs.org";  exit 1; }

# ── Backend ───────────────────────────────────
echo -e "\n${GREEN}[1/4] Setting up Python virtual environment...${NC}"
cd "$ROOT/backend"
[ ! -d venv ] && python3 -m venv venv
source venv/bin/activate
pip install -q --upgrade pip
pip install -q -r requirements.txt
python -m spacy download en_core_web_sm --quiet 2>/dev/null || true

[ ! -f .env ] && cp .env.example .env && echo -e "${YELLOW}  Created backend/.env — add API keys for LLM support${NC}"

# ── Frontend ──────────────────────────────────
echo -e "${GREEN}[2/4] Installing frontend dependencies...${NC}"
cd "$ROOT/frontend"
[ ! -f .env ] && cp .env.example .env
npm install --silent

# ── Launch ────────────────────────────────────
echo -e "${GREEN}[3/4] Starting servers...${NC}\n"
echo -e "  ${BLUE}Chat UI  →${NC} http://localhost:3000"
echo -e "  ${BLUE}API Docs →${NC} http://localhost:8000/docs"
echo -e "  ${BLUE}Health   →${NC} http://localhost:8000/health"
echo -e "\n  Press ${YELLOW}Ctrl+C${NC} to stop\n"

cd "$ROOT/backend"
source venv/bin/activate
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload &
BACKEND_PID=$!

cd "$ROOT/frontend"
npm run dev &
FRONTEND_PID=$!

trap "echo ''; echo 'Stopping...'; kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; exit 0" SIGINT
wait
