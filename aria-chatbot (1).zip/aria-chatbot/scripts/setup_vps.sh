#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
#  Aria Chatbot — One-command VPS Production Setup
#  Tested on: Ubuntu 22.04 LTS
#
#  Usage:
#    1. SSH into your server: ssh root@YOUR_SERVER_IP
#    2. Run: curl -fsSL https://raw.githubusercontent.com/YOUR/chatbot/main/deploy/setup_vps.sh | bash
#       OR upload this file and run: bash setup_vps.sh
# ─────────────────────────────────────────────────────────────
set -e

DOMAIN="${1:-yourdomain.com}"
REPO_URL="${2:-https://github.com/YOUR_NAME/chatbot.git}"
APP_DIR="/opt/chatbot"

GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
log()  { echo -e "${GREEN}[✓]${NC} $1"; }
info() { echo -e "${BLUE}[→]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }

echo -e "${BLUE}"
echo "╔══════════════════════════════════════════════╗"
echo "║   Aria AI Chatbot — Production VPS Setup     ║"
echo "╚══════════════════════════════════════════════╝"
echo -e "${NC}"
echo "Domain: $DOMAIN"
echo "Repo:   $REPO_URL"
echo ""

# ── 1. System update ──────────────────────────────────────────
info "Updating system packages..."
apt-get update -qq && apt-get upgrade -y -qq
log "System updated"

# ── 2. Install Docker ─────────────────────────────────────────
info "Installing Docker..."
if ! command -v docker &>/dev/null; then
  curl -fsSL https://get.docker.com | sh
  systemctl enable docker
  systemctl start docker
fi
log "Docker ready: $(docker --version)"

# ── 3. Install Docker Compose ─────────────────────────────────
info "Installing Docker Compose..."
if ! command -v docker &>/dev/null || ! docker compose version &>/dev/null; then
  apt-get install -y docker-compose-plugin
fi
log "Docker Compose ready"

# ── 4. Install Certbot (free SSL) ────────────────────────────
info "Installing Certbot for SSL..."
apt-get install -y certbot -qq
log "Certbot ready"

# ── 5. Clone the repo ─────────────────────────────────────────
info "Cloning chatbot repository..."
if [ -d "$APP_DIR" ]; then
  cd "$APP_DIR" && git pull
else
  git clone "$REPO_URL" "$APP_DIR"
fi
cd "$APP_DIR"
log "Repository ready at $APP_DIR"

# ── 6. Create .env from production template ───────────────────
if [ ! -f "$APP_DIR/.env" ]; then
  cp "$APP_DIR/deploy/.env.production" "$APP_DIR/.env"
  # Replace placeholder domain
  sed -i "s/yourdomain.com/$DOMAIN/g" "$APP_DIR/.env"
  warn "IMPORTANT: Edit $APP_DIR/.env and add your API keys!"
  warn "  nano $APP_DIR/.env"
  warn "  Add: ANTHROPIC_API_KEY, DB_PASSWORD, REDIS_PASSWORD"
  echo ""
  read -p "Press ENTER after you have edited .env to continue..." _
fi

# ── 7. Generate strong passwords if placeholders exist ────────
source "$APP_DIR/.env"
if [[ "$DB_PASSWORD" == "CHANGE_THIS_PASSWORD" ]]; then
  NEW_DB_PASS=$(openssl rand -base64 24)
  NEW_REDIS_PASS=$(openssl rand -base64 24)
  sed -i "s/CHANGE_THIS_PASSWORD/$NEW_DB_PASS/g" "$APP_DIR/.env"
  # Update Redis password specifically
  sed -i "s/REDIS_PASSWORD=.*/REDIS_PASSWORD=$NEW_REDIS_PASS/" "$APP_DIR/.env"
  log "Generated secure passwords"
fi

# ── 8. Get SSL certificate ────────────────────────────────────
info "Getting SSL certificate for $DOMAIN..."
mkdir -p "$APP_DIR/deploy/vps/nginx/ssl"

# Stop anything on port 80 temporarily
docker compose -f "$APP_DIR/deploy/vps/docker-compose.prod.yml" down 2>/dev/null || true

certbot certonly --standalone \
  --non-interactive \
  --agree-tos \
  --email "admin@$DOMAIN" \
  -d "$DOMAIN" \
  -d "www.$DOMAIN" || warn "SSL cert failed — check your domain points to this server IP"

# Copy certs to nginx ssl folder
cp /etc/letsencrypt/live/$DOMAIN/fullchain.pem "$APP_DIR/deploy/vps/nginx/ssl/"
cp /etc/letsencrypt/live/$DOMAIN/privkey.pem   "$APP_DIR/deploy/vps/nginx/ssl/"
log "SSL certificate installed"

# ── 9. Build frontend ─────────────────────────────────────────
info "Building React frontend..."
cd "$APP_DIR/frontend"
source "$APP_DIR/.env"
docker run --rm \
  -v "$APP_DIR/frontend":/app \
  -w /app \
  -e VITE_WS_URL="$VITE_WS_URL" \
  node:20-alpine \
  sh -c "npm ci && npm run build"
log "Frontend built"

# ── 10. Start all services ────────────────────────────────────
info "Starting production services..."
cd "$APP_DIR"
docker compose -f deploy/vps/docker-compose.prod.yml up -d --build

log "All services started"

# ── 11. Set up auto-SSL renewal ───────────────────────────────
(crontab -l 2>/dev/null; echo "0 3 * * * certbot renew --quiet && cp /etc/letsencrypt/live/$DOMAIN/*.pem $APP_DIR/deploy/vps/nginx/ssl/ && docker compose -f $APP_DIR/deploy/vps/docker-compose.prod.yml restart nginx") | crontab -
log "SSL auto-renewal scheduled"

# ── 12. Set up auto-update on git push (optional) ─────────────
cat > /etc/systemd/system/chatbot-updater.service << EOF
[Unit]
Description=Chatbot auto-update
After=network.target

[Service]
Type=oneshot
WorkingDirectory=$APP_DIR
ExecStart=/bin/bash -c 'git pull && docker compose -f deploy/vps/docker-compose.prod.yml up -d --build'
EOF

# ── Final status ──────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║         🎉 Deployment Complete!              ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${BLUE}Chat UI:${NC}   https://$DOMAIN"
echo -e "  ${BLUE}API:${NC}       https://$DOMAIN/api/v1"
echo -e "  ${BLUE}Health:${NC}    https://$DOMAIN/health"
echo ""
echo -e "  ${BLUE}View logs:${NC}  docker compose -f $APP_DIR/deploy/vps/docker-compose.prod.yml logs -f"
echo -e "  ${BLUE}Restart:${NC}    docker compose -f $APP_DIR/deploy/vps/docker-compose.prod.yml restart"
echo ""

# Quick health check
sleep 5
curl -sf "http://localhost/health" && echo -e "${GREEN}Health check passed ✅${NC}" || warn "Health check failed — check logs"
