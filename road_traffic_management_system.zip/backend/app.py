from flask import Flask
app=Flask(__name__)
@app.route('/')
def home():
    return {'status':'running'}
app.run(debug=True)
